const options: mmOptionsOffcanvas = {
    use: true,
    position: 'left'
};
export default options;