const options : mmOptionsBackbutton = {
	close: false,
	open: false
};

export default options;
