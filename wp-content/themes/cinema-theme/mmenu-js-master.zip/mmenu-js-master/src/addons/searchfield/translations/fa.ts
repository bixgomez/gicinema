export default {
    'cancel': 'انصراف',
    'Cancel searching': 'لغو جستجو',
    'Clear searchfield': 'پاک کردن فیلد جستجو',
    'No results found.': 'نتیجه‌ای یافت نشد.',
    'Search': 'جستجو',
};
