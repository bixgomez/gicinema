//	Add-on options interface.
interface mmOptionsScrollbugfix {

	/** Whether or not to fix the scrolling bug. */
	fix?: boolean
}
