export default {
    'Close submenu': 'Закрыть подменю',
	'Menu': 'Меню',
    'Open submenu': 'Открыть подменю',
    'Toggle submenu': 'Переключить подменю'
};