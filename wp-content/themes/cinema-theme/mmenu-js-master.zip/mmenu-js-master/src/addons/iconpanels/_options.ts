const options: mmOptionsIconpanels = {
	add: false,
	blockPanel: true,
	visible: 3
};

export default options;
