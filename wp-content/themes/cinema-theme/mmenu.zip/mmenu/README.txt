Please visit mmenujs.com/wordpress-plugin/readme for all needed information on how to install and use this plugin.
