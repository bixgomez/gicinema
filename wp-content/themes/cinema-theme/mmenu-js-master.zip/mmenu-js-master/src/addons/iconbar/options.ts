const options: mmOptionsIconbar = {
    use: false,
    top: [],
    bottom: [],
    position: 'left',
    type: 'default'
};

export default options;
