export default {
    'cancel': 'cancelar',
    'Cancel searching': 'Cancelar pesquisa',
    'Clear searchfield': 'Limpar campo de pesquisa',
    'No results found.': 'Nenhum resultado encontrado.',
    'Search': 'Buscar',
};
