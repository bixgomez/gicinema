export default {
    'Close menu': 'Menu sluiten',
    'Open menu': 'Menu openen',
}