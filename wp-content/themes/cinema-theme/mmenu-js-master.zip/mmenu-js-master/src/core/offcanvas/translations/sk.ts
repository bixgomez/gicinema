export default {
    'Close menu': 'Zatvoriť menu',
    'Open menu': 'Otvoriť menu',
}