const options: mmOptionsSidebar = {
    collapsed: {
        use: false,
        blockMenu: true
    },
    expanded: {
        use: false,
        initial: 'open'
    }
};
export default options;
