const options : string = 'light';

export default options;
